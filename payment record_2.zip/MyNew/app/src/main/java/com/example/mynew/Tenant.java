package com.example.mynew;

public class Tenant {
    private String firstname;
    private String surname;
    private String phone_number;
    private String room_number;
    private String date_occupied;
    private String exit_date;
    private String amount_paid;
    private String date_paid;
    private String balance;

    public Tenant() {
    }

    public Tenant(String firstname, String surname, String phone_number, String room_number, String date_occupied, String exit_date, String amount_paid, String date_paid, String balance) {
        this.firstname = firstname;
        this.surname = surname;
        this.phone_number = phone_number;
        this.room_number = room_number;
        this.date_occupied = date_occupied;
        this.exit_date = exit_date;
        this.amount_paid = amount_paid;
        this.date_paid = date_paid;
        this.balance = balance;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public String getRoom_number() {
        return room_number;
    }

    public void setRoom_number(String room_number) {
        this.room_number = room_number;
    }

    public String getDate_occupied() {
        return date_occupied;
    }

    public void setDate_occupied(String date_occupied) {
        this.date_occupied = date_occupied;
    }

    public String getExit_date() {
        return exit_date;
    }

    public void setExit_date(String exit_date) {
        this.exit_date = exit_date;
    }

    public String getAmount_paid() {
        return amount_paid;
    }

    public void setAmount_paid(String amount_paid) {
        this.amount_paid = amount_paid;
    }

    public String getDate_paid() {
        return date_paid;
    }

    public void setDate_paid(String date_paid) {
        this.date_paid = date_paid;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }
}

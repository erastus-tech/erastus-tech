package com.example.mynew;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LandActivity extends AppCompatActivity {

    private EditText landname,landpassword;
    private Button Loginl;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_land);


        landname=(EditText)findViewById(R.id.landu);
        landpassword=(EditText)findViewById(R.id.landp);
        Loginl=(Button) findViewById(R.id.log1);

        progressDialog=new ProgressDialog(this);

        Loginl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate (landname.getText().toString(), landpassword.getText().toString());
            }
        });
    }

    private void validate(String landname, String landpassword) {
        progressDialog.setMessage("Loading");
        progressDialog.show();
        if (landname.equals("caretaker") && landpassword.equals("654321")){
            progressDialog.dismiss();
            Toast.makeText(LandActivity.this,"Login successful",Toast.LENGTH_SHORT).show();
            Intent intent=new Intent(LandActivity.this,Caretaker3Activity.class);
            startActivity(intent);
        }
    }
    /*private boolean validate(){
        Boolean result=false;
        String name=landname.getText().toString();
        String password=landpassword.getText().toString();


        if (name.isEmpty() &&password.isEmpty()){
            Toast.makeText(this,"please enter all the details",Toast.LENGTH_SHORT).show();
        }else{
            result=true;
        }
        return result;
    }*/


}

package com.example.mynew;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class CaretakerActivity extends AppCompatActivity {
    private EditText cname,cpassword;
    private Button Login;
    private TextView Register;
    private TextView forgeet;
    private FirebaseAuth firebaseAuth;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caretaker);

        cname=(EditText)findViewById(R.id.namec);
        cpassword=(EditText)findViewById(R.id.passwordc);
        Login=(Button) findViewById(R.id.loginc);
        Register =(TextView) findViewById(R.id.registerc);
        forgeet =(TextView) findViewById(R.id.passwordrl);

        firebaseAuth=FirebaseAuth.getInstance();
        progressDialog=new ProgressDialog(this);

        FirebaseUser user=firebaseAuth.getCurrentUser();

        if (user !=null){
            finish();
            startActivity(new Intent(CaretakerActivity.this,Caretaker3Activity.class));
        }
        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate(cname.getText().toString(),cpassword.getText().toString());

            }
        });

        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CaretakerActivity.this,Caretaker1Activity.class));
            }
        });

        forgeet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CaretakerActivity.this,PasswordlActivity.class));
            }
        });


    }
    private void validate(String cname,String cpassword){

        progressDialog.setMessage("Loading");
        progressDialog.show();

        firebaseAuth.signInWithEmailAndPassword(cname,cpassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){
                    progressDialog.dismiss();
                    Toast.makeText(CaretakerActivity.this,"Login successful",Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(CaretakerActivity.this,LandActivity.class));
                }else {
                    Toast.makeText(CaretakerActivity.this,"Login failed",Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(CaretakerActivity.this,CaretakerActivity.class));
                    finish();
                }


            }
        });

    }
    /*private boolean validate(){
        Boolean result=false;
        String name=cname.getText().toString();
        String password=cpassword.getText().toString();


        if (name.isEmpty() &&password.isEmpty()){
            Toast.makeText(this,"please enter all the details",Toast.LENGTH_SHORT).show();
        }else{
            result=true;
        }
        return result;
    }*/
}

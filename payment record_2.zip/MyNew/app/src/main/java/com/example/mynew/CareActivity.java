package com.example.mynew;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CareActivity extends AppCompatActivity {

    private EditText carename,carepassword;
    private Button Login2;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_care);

        carename=(EditText)findViewById(R.id.careu);
        carepassword=(EditText)findViewById(R.id.carep);
        Login2=(Button) findViewById(R.id.log1);

        progressDialog=new ProgressDialog(this);

        Login2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate (carename.getText().toString(), carepassword.getText().toString());
            }
        });
    }


    private void validate(String landname, String landpassword) {
        progressDialog.setMessage("Loading");
        progressDialog.show();
        if (landname.equals("caretaker") && landpassword.equals("654321")) {
            progressDialog.dismiss();
            Toast.makeText(CareActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(CareActivity.this, Caretaker3Activity.class);
            startActivity(intent);
        } else {
            Toast.makeText(CareActivity.this, "Login is not successful", Toast.LENGTH_SHORT).show();
        }
    }
    /*private boolean validate(){
        Boolean result=false;
        String name=carename.getText().toString();
        String password=carepassword.getText().toString();


        if (name.isEmpty() &&password.isEmpty()){
            Toast.makeText(this,"please enter all the details",Toast.LENGTH_SHORT).show();
        }else{
            result=true;
        }
        return result;
    }*/

}

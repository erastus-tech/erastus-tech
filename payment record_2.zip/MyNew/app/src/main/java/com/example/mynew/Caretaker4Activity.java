package com.example.mynew;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class Caretaker4Activity extends AppCompatActivity {
    private EditText namef,namel,numberp,numberr,occupiedd,datee,paida,paidd,balanc;
    private Button update,delete,back;

    private String key;
    private String first_name;
    private String last_name;
    private String phone_number;
    private String room_number;
    private String date_occupied;
    private String exit_date;
    private String amount_paid;
    private String date_paid;
    private String balance;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caretaker4);

        key=getIntent().getStringExtra("key");
        first_name=getIntent().getStringExtra("first_name");
        last_name=getIntent().getStringExtra("last_name");
        phone_number=getIntent().getStringExtra("phone_number");
        room_number=getIntent().getStringExtra("room_number");
        date_occupied=getIntent().getStringExtra("date_occupied");
        exit_date=getIntent().getStringExtra("exit_date");
        amount_paid=getIntent().getStringExtra("amount_paid");
        date_paid=getIntent().getStringExtra("date_paid");
        balance=getIntent().getStringExtra("balance");

        namef=(EditText)findViewById(R.id.fname4);
        namef.setText(first_name);
        namel=(EditText)findViewById(R.id.lname4);
        namel.setText(last_name);
        numberp=(EditText)findViewById(R.id.phonenumber4);
        numberp.setText(phone_number);
        numberr=(EditText)findViewById(R.id.roomnumber4);
        numberr.setText(room_number);
        occupiedd=(EditText)findViewById(R.id.dateoccupied4);
        occupiedd.setText(date_occupied);
        datee=(EditText)findViewById(R.id.exitdate4);
        datee.setText(exit_date);
        paida=(EditText)findViewById(R.id.amountpaid4);
        paida.setText(amount_paid);
        paidd=(EditText)findViewById(R.id.datepaid4);
        paidd.setText(date_paid);
        balanc=(EditText)findViewById(R.id.balance4);
        balanc.setText(balance);


        update=(Button) findViewById(R.id.update4);
        back=(Button) findViewById(R.id.backc4);
        delete=(Button) findViewById(R.id.delete4);

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Tenant tenant=new Tenant();
                tenant.setFirstname(namef.getText().toString());
                tenant.setSurname(namel.getText().toString());
                tenant.setPhone_number(numberp.getText().toString());
                tenant.setRoom_number(numberr.getText().toString());
                tenant.setDate_occupied(occupiedd.getText().toString());
                tenant.setExit_date(datee.getText().toString());
                tenant.setAmount_paid(paida.getText().toString());
                tenant.setDate_paid(paidd.getText().toString());
                tenant.setBalance(balanc.getText().toString());

                new FirebaseDatabaseHelper().updateTenant(key, tenant, new FirebaseDatabaseHelper.DataStatus() {
                    @Override
                    public void DataIsLoaded(List<Tenant> tenants, List<String> keys) {

                    }

                    @Override
                    public void DataIsInserted() {

                    }

                    @Override
                    public void DataIsUpdated() {
                        Toast.makeText(Caretaker4Activity.this, "Tenant record has been updated successfully",Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void DataIsDeleted() {

                    }
                });
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new FirebaseDatabaseHelper().deleteTenant(key, new FirebaseDatabaseHelper.DataStatus() {
                    @Override
                    public void DataIsLoaded(List<Tenant> tenants, List<String> keys) {

                    }

                    @Override
                    public void DataIsInserted() {

                    }

                    @Override
                    public void DataIsUpdated() {

                    }

                    @Override
                    public void DataIsDeleted() {
                        Toast.makeText(Caretaker4Activity.this, "Tenant record has been deleted successfully",Toast.LENGTH_LONG).show();
                        finish(); return;

                    }
                });

            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); return;
            }
        });
    }

    public String getAmount_paid() {
        return amount_paid;
    }
}

package com.example.mynew;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class FirebaseDatabaseHelper {
    private FirebaseDatabase mDatabase;
    private DatabaseReference mreferenceTenants;
    private List<Tenant> tenants=new ArrayList<>();




    public interface DataStatus{
        void DataIsLoaded(List<Tenant> tenants, List<String> keys );
        void DataIsInserted();
        void DataIsUpdated();
        void DataIsDeleted();
    }
    public FirebaseDatabaseHelper(){
        mDatabase=FirebaseDatabase.getInstance();
        mreferenceTenants=mDatabase.getReference("tenants");
    }

    public void readTenants(final DataStatus dataStatus){
        mreferenceTenants.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                tenants.clear();
                List<String> keys=new ArrayList<>();
                for (DataSnapshot keyNode :dataSnapshot.getChildren()){
                    keys.add(keyNode.getKey());
                    Tenant tenant= keyNode.getValue(Tenant.class);
                    tenants.add(tenant);
                }
                dataStatus.DataIsLoaded(tenants,keys);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void addTenant(Tenant tenant, final DataStatus dataStatus){
        String key=mreferenceTenants.push().getKey();
        mreferenceTenants.child(key).setValue(tenant)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                    }
                });
    }
    public void updateTenant(String key,Tenant tenant,final DataStatus dataStatus){
        mreferenceTenants.child(key).setValue(tenant)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        dataStatus.DataIsUpdated();
                    }
                });
    }
    public void deleteTenant(String key,final DataStatus dataStatus){
        mreferenceTenants.child(key).setValue(null)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        dataStatus.DataIsDeleted();
                    }
                });
    }
}

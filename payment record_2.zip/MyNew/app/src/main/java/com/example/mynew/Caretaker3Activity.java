package com.example.mynew;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

public class Caretaker3Activity extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;
    private Button Logout,Registration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caretaker3);

        firebaseAuth=FirebaseAuth.getInstance();

        Logout=(Button)findViewById(R.id.logoutc3);
        Registration=(Button)findViewById(R.id.registrationc3);


        Logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firebaseAuth.signOut();
                finish();
                startActivity(new Intent(Caretaker3Activity.this,DashboardActivity.class));
            }
        });



        Registration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Caretaker3Activity.this,RegistrationActivity.class));
            }
        });

    }
}

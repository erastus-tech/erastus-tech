package com.example.mynew;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Landlord1Activity extends AppCompatActivity {
    private EditText lName,lPassword,lEmail;
    private Button lSignup;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landlord1);

        firebaseAuth=FirebaseAuth.getInstance();
        lName=(EditText)findViewById(R.id.namel1);
        lEmail=(EditText)findViewById(R.id.emaill1);
        lPassword=(EditText)findViewById(R.id.passwordl1);
        lSignup=(Button) findViewById(R.id.registerl1);

        lSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validate()) {
                    String user_email = lEmail.getText().toString().trim();
                    String user_password = lPassword.getText().toString().trim();

                    firebaseAuth.createUserWithEmailAndPassword(user_email, user_password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                FirebaseUser user = firebaseAuth.getCurrentUser();
                                Toast.makeText(Landlord1Activity.this, "Registration is successful", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(Landlord1Activity.this, LandlordActivity.class));
                            } else {
                                Toast.makeText(Landlord1Activity.this, "Registration is not successful", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });
    }
    private boolean validate(){
        Boolean result=false;
        String name=lName.getText().toString();
        String password=lPassword.getText().toString();
        String email=lEmail.getText().toString();

        if (name.isEmpty() &&password.isEmpty() &&email.isEmpty()){
            Toast.makeText(this,"please enter all the details",Toast.LENGTH_SHORT).show();
        }else{
            result=true;
        }
        return result;
    }

}

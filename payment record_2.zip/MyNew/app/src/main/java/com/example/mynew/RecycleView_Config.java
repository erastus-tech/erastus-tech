package com.example.mynew;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecycleView_Config {
    private Context mContext;
    private TenantsAdapter mTenantsAdapter;
    public void setConfig(RecyclerView recyclerView, Context context,List<Tenant> tenants, List<String> keys){
        mContext=context;
        mTenantsAdapter=new TenantsAdapter(tenants,keys);
        recyclerView.setLayoutManager(new LinearLayoutManager(context));
        recyclerView.setAdapter(mTenantsAdapter);
    }

    class TenantItemView extends RecyclerView.ViewHolder{
        private TextView mfname;
        private TextView msname;
        private TextView mpnumber;
        private TextView mrnumber;
        private TextView mdoccupied;
        private TextView medate;
        private TextView mapaid;
        private TextView mdpaid;
        private TextView mbal;

        private String key;

        public TenantItemView(ViewGroup parent){
            super(LayoutInflater.from(mContext).
                    inflate(R.layout.record_list_item,parent,false));

            mfname=(TextView) itemView.findViewById(R.id.first);
            msname=(TextView) itemView.findViewById(R.id.last);
            mpnumber=(TextView) itemView.findViewById(R.id.phone);
            mrnumber=(TextView) itemView.findViewById(R.id.room);
            mdoccupied=(TextView) itemView.findViewById(R.id.occupied);
            medate=(TextView) itemView.findViewById(R.id.exitdate);
            mapaid=(TextView) itemView.findViewById(R.id.paida);
            mdpaid=(TextView) itemView.findViewById(R.id.paidd);
            mbal=(TextView) itemView.findViewById(R.id.blnce);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent=new Intent(mContext,Caretaker4Activity.class);
                    intent.putExtra("key",key);
                    intent.putExtra("first_name",mfname.getText().toString());
                    intent.putExtra("last_name",msname.getText().toString());
                    intent.putExtra("phone_number",mpnumber.getText().toString());
                    intent.putExtra("room_number",mrnumber.getText().toString());
                    intent.putExtra("date_occupied",mdoccupied.getText().toString());
                    intent.putExtra("exit_date",medate.getText().toString());
                    intent.putExtra("amount_paid",mapaid.getText().toString());
                    intent.putExtra("date_paid",mdpaid.getText().toString());
                    intent.putExtra("balance",mbal.getText().toString());

                    mContext.startActivity(intent);
                }
            });
        }
        public void bind(Tenant tenant, String key){
            mfname.setText(tenant.getFirstname());
            msname.setText(tenant.getSurname());
            mpnumber.setText(tenant.getPhone_number());
            mrnumber.setText(tenant.getRoom_number());
            mdoccupied.setText(tenant.getDate_occupied());
            medate.setText(tenant.getExit_date());
            mapaid.setText(tenant.getAmount_paid());
            mdpaid.setText(tenant.getDate_paid());
            mbal.setText(tenant.getBalance());
            this.key=key;
        }

    }
    class TenantsAdapter extends RecyclerView.Adapter<TenantItemView>{
        private List<Tenant> mTenantList;
        private List<String> mKeys;

        public TenantsAdapter(List<Tenant> mTenantList, List<String> mKeys) {
            this.mTenantList = mTenantList;
            this.mKeys = mKeys;
        }

        @NonNull
        @Override
        public TenantItemView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new TenantItemView(parent);
        }

        @Override
        public void onBindViewHolder(@NonNull TenantItemView holder, int position) {
            holder.bind(mTenantList.get(position),mKeys.get(position));
        }

        @Override
        public int getItemCount() {
            return mTenantList.size();
        }
    }


}

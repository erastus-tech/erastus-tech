package com.example.mynew;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LandlordActivity extends AppCompatActivity {
    private EditText nname,ppassword;
    private Button Login;
    private TextView Register;
    private FirebaseAuth firebaseAuth;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landlord);

        nname=(EditText)findViewById(R.id.namel);
        ppassword=(EditText)findViewById(R.id.passwordl);
        Login=(Button) findViewById(R.id.loginl);



        firebaseAuth=FirebaseAuth.getInstance();
        progressDialog=new ProgressDialog(this);

        FirebaseUser user=firebaseAuth.getCurrentUser();

        if (user !=null){
            finish();
            startActivity(new Intent(LandlordActivity.this,Landlord3Activity.class));
        }




        Login.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                validate(nname.getText().toString(),ppassword.getText().toString());



            }
        });


    }
    private void validate(String name , String password){


        if (name.isEmpty() || password.isEmpty()){
            Toast.makeText(this,"please enter all the details",Toast.LENGTH_SHORT).show();}


        progressDialog.setMessage("Loading");
        progressDialog.show();

        firebaseAuth.signInWithEmailAndPassword(name,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){
                    progressDialog.dismiss();
                    Toast.makeText(LandlordActivity.this,"Login successful",Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(LandlordActivity.this,Landlord3Activity.class));
                }else {
                    Toast.makeText(LandlordActivity.this,"Login failed",Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(LandlordActivity.this,LandlordActivity.class));

                }
            }
        });
    }
    /*private boolean validate(){
        Boolean result=false;
        String name=nname.getText().toString();
        String password=ppassword.getText().toString();


        if (name.isEmpty() || password.isEmpty()){
            Toast.makeText(this,"please enter all the details",Toast.LENGTH_SHORT).show();
        }else{
            result=true;
        }
        return result;
    }*/
}

package com.example.mynew;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class RegistrationActivity extends AppCompatActivity {
    private EditText fname,lname,pnumber,rnumber,doccupied,edate,apaid,dpaid,bal;
    private Button submit,back,morst;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        fname=(EditText)findViewById(R.id.fnamer);
        lname=(EditText)findViewById(R.id.snamer);
        pnumber=(EditText)findViewById(R.id.phonenumberr);
        rnumber=(EditText)findViewById(R.id.roomnumber);
        doccupied=(EditText)findViewById(R.id.dateoccupied);
        edate=(EditText)findViewById(R.id.exitdate);
        apaid=(EditText)findViewById(R.id.amountpaidr);
        dpaid=(EditText)findViewById(R.id.datepaidr);
        bal=(EditText)findViewById(R.id.balancer);

        submit=(Button) findViewById(R.id.registerr);
        back=(Button) findViewById(R.id.backr);
        morst=(Button) findViewById(R.id.morer);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Tenant tenant=new Tenant();
                tenant.setFirstname(fname.getText().toString());
                tenant.setSurname(lname.getText().toString());
                tenant.setPhone_number(pnumber.getText().toString());
                tenant.setRoom_number(rnumber.getText().toString());
                tenant.setDate_occupied(doccupied.getText().toString());
                tenant.setExit_date(edate.getText().toString());
                tenant.setAmount_paid(apaid.getText().toString());
                tenant.setDate_paid(dpaid.getText().toString());
                tenant.setBalance(bal.getText().toString());


                new FirebaseDatabaseHelper().addTenant(tenant, new FirebaseDatabaseHelper.DataStatus() {
                    @Override
                    public void DataIsLoaded(List<Tenant> tenants, List<String> keys) {

                    }

                    @Override
                    public void DataIsInserted() {
                        Toast.makeText(RegistrationActivity.this,"Tenant added successfully",Toast.LENGTH_LONG).show();
                        startActivity(new Intent(RegistrationActivity.this,Caretaker3Activity.class));

                    }

                    @Override
                    public void DataIsUpdated() {

                    }

                    @Override
                    public void DataIsDeleted() {

                    }
                });
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); return;
            }
        });

        morst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegistrationActivity.this,RecordActivity.class));
            }
        });
    }
}

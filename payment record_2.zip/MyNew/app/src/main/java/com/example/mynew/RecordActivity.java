package com.example.mynew;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;

import java.util.List;

public class RecordActivity extends AppCompatActivity {

    private RecyclerView mRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record);
        mRecyclerView=(RecyclerView)findViewById(R.id.recycleview_tenants);
        new FirebaseDatabaseHelper().readTenants(new FirebaseDatabaseHelper.DataStatus() {
            @Override
            public void DataIsLoaded(List<Tenant> tenants, List<String> keys) {
                findViewById(R.id.loading_tenants).setVisibility(View.GONE);
                new RecycleView_Config().setConfig(mRecyclerView,RecordActivity.this,tenants,keys);
            }

            @Override
            public void DataIsInserted() {

            }

            @Override
            public void DataIsUpdated() {

            }

            @Override
            public void DataIsDeleted() {

            }
        });
    }
}
